### Tips
* Use https://gitlab.com/Franc1sco/Franug-PRIVATE-knifes/issues if you found bugs, you have questions, or you want a new feature.
* Read the rules here: https://github.com/Franc1sco/Franug-PRIVATE-PLUGINS

### Installation:
* Install required plugin: https://gitlab.com/Franc1sco/Franug-GiveNamedItem (if you dont have access, then send a email to franug13@gmail.com with your gitlab email and paypal account that you use to pay this plugin)
* Disable "FollowCSGOServerGuidelines" option. More info: https://forums.alliedmods.net/showthread.php?t=279854
* Dont use your own tokens. Use this website https://csgo.tokenstash.com
* Unzip file in addons/sourcemod/
* You dont need to upload the .sp file
* If you want a !ws plugin you need to use the private ws version, if you still dont have it, then buy it from me (Franc1sco franug)
* Configure addons/sourcemod/configs/csgo_knives.cfg


### Optional

* Compatible with https://forums.alliedmods.net/showthread.php?t=276733